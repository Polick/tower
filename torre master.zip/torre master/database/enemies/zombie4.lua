return {
  name = "ZOMBIE4",
  sprite = 'zumbi-bruxa',
  path = 'enemies.zombie',
  power = 10,
  cost = 30,
  delay = 2,
  dir = new (Vec) {-1,0},
  movement = true,
  hitbox = {-20,20,-20,20},
  description = ":(",
  group = 'enemies',
  max_hp = 130,
}
