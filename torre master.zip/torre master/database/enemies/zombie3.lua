return {
  name = "ZOMBIE3",
  sprite = 'zumbi-boss',
  path = 'enemies.zombie',
  power = 100,
  cost = 50,
  delay = 2,
  dir = new (Vec) {-1,0},
  movement = true,
  hitbox = {-20,20,-20,20},
  description = ":(",
  group = 'enemies',
  max_hp = 300,
}
