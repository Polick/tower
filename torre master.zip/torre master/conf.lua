
function love.conf(t)
  t.window.title = "Tower Defense"
  t.window.width = 1280
  t.window.height = 720
  t.console = true
  t.window.vsync = false
end


